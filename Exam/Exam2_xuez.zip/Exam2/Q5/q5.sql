CREATE DATABASE IF NOT EXISTS exam;

USE exam;

CREATE TABLE examData (
name varchar(50) DEFAULT NULL,
cno varchar(25) DEFAULT NULL,
cname varchar(50) DEFAULT NULL,
letter varchar(5) DEFAULT NULL,
username varchar(25) DEFAULT NULL
);
